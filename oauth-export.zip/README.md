# OAuth Integration for Google Sheets and Airtable

This repository contains the core OAuth implementation for authenticating with Google Sheets and Airtable APIs.

## Features

- Complete OAuth 2.0 flow with PKCE for security
- Token storage and management
- Service connection UI components
- API wrappers for Google Sheets and Airtable

## Getting Started

1. Configure your OAuth credentials in environment variables:
   - `GOOGLE_CLIENT_ID`
   - `GOOGLE_CLIENT_SECRET`
   - `AIRTABLE_CLIENT_ID` 
   - `AIRTABLE_CLIENT_SECRET`

2. Configure redirect URIs in the OAuth providers' dashboards to point to your callback endpoint

3. Implement storage for the OAuth tokens (default uses in-memory storage)

## Files Overview

- `client/src/lib/oauth.ts` - Core OAuth initialization functions
- `client/src/pages/auth-callback.tsx` - Callback handler for OAuth redirects
- `client/src/components/setup/connect-services-step.tsx` - Connection UI
- `server/services/airtable.ts` - Airtable API wrapper
- `server/services/google-sheets.ts` - Google Sheets API wrapper
- `server/routes.ts` - API routes for OAuth flow
- `server/storage.ts` - Token storage interface
- `shared/schema.ts` - Shared type definitions
