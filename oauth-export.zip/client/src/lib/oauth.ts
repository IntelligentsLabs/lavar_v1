import { nanoid } from 'nanoid';
import { apiRequest } from './queryClient';
import { OAuthState } from '@/types';

// OAuth configuration
const AIRTABLE_CLIENT_ID = import.meta.env.VITE_AIRTABLE_CLIENT_ID;
const GOOGLE_CLIENT_ID = import.meta.env.VITE_GOOGLE_CLIENT_ID;

// Log the client IDs being used (in development only)
if (import.meta.env.DEV) {
  console.log('Using Airtable Client ID:', AIRTABLE_CLIENT_ID ? 'Found' : 'Missing');
  console.log('Using Google Client ID:', GOOGLE_CLIENT_ID ? 'Found' : 'Missing');
}

// Use a consistent redirect URI across the application
const REDIRECT_URI = 'https://fa5d8be3-1109-4f89-ad76-48cbd7c649b7-00-3v44c74ztyuq.picard.replit.dev/auth/callback';

// Generate a code verifier for PKCE
export const generateCodeVerifier = (): string => {
  return nanoid(64);
};

// Generate a code challenge from the verifier (for PKCE)
export const generateCodeChallenge = async (verifier: string): Promise<string> => {
  const data = new TextEncoder().encode(verifier);
  const digest = await window.crypto.subtle.digest('SHA-256', data);
  
  // Convert to base64 URL
  return btoa(String.fromCharCode(...new Uint8Array(digest)))
    .replace(/\+/g, '-')
    .replace(/\//g, '_')
    .replace(/=+$/, '');
};

// Save OAuth state for verification later
export const saveOAuthState = (state: OAuthState): void => {
  localStorage.setItem(`oauth_state_${state.state}`, JSON.stringify(state));
};

// Get OAuth state by state parameter
export const getOAuthState = (state: string): OAuthState | null => {
  const stateJson = localStorage.getItem(`oauth_state_${state}`);
  if (!stateJson) return null;
  
  try {
    return JSON.parse(stateJson) as OAuthState;
  } catch (e) {
    console.error('Failed to parse OAuth state:', e);
    return null;
  }
};

// Clear OAuth state after use
export const clearOAuthState = (state: string): void => {
  localStorage.removeItem(`oauth_state_${state}`);
};

// Initiate Airtable OAuth flow
export const initiateAirtableAuth = async (): Promise<void> => {
  const state = nanoid();
  const codeVerifier = generateCodeVerifier();
  const codeChallenge = await generateCodeChallenge(codeVerifier);
  const redirectUri = 'https://fa5d8be3-1109-4f89-ad76-48cbd7c649b7-00-3v44c74ztyuq.picard.replit.dev/auth/callback';
  
  // Save state for verification on callback
  saveOAuthState({
    provider: 'airtable',
    redirectUri,
    codeVerifier,
    state
  });
  
  // Construct authorization URL for Airtable
  const authUrl = new URL('https://airtable.com/oauth2/v1/authorize');
  authUrl.searchParams.append('client_id', AIRTABLE_CLIENT_ID);
  authUrl.searchParams.append('redirect_uri', redirectUri);
  authUrl.searchParams.append('response_type', 'code');
  authUrl.searchParams.append('state', state);
  authUrl.searchParams.append('code_challenge', codeChallenge);
  authUrl.searchParams.append('code_challenge_method', 'S256');
  // Make sure to include all required scopes
  authUrl.searchParams.append('scope', 'data.records:read data.records:write schema.bases:read schema.bases:write');
  
  // Log authorization details (in development only)
  if (import.meta.env.DEV) {
    console.log('Airtable Auth URL:', authUrl.toString());
    console.log('Redirect URI:', redirectUri);
    console.log('Using client ID:', AIRTABLE_CLIENT_ID);
  }
  
  // Redirect to authorization URL
  window.location.href = authUrl.toString();
};

// Initiate Google OAuth flow
export const initiateGoogleAuth = async (): Promise<void> => {
  const state = nanoid();
  const codeVerifier = generateCodeVerifier();
  const codeChallenge = await generateCodeChallenge(codeVerifier);
  const redirectUri = REDIRECT_URI;
  
  // Save state for verification on callback
  saveOAuthState({
    provider: 'google',
    redirectUri,
    codeVerifier,
    state
  });
  
  // Construct authorization URL
  const authUrl = new URL('https://accounts.google.com/o/oauth2/v2/auth');
  authUrl.searchParams.append('client_id', GOOGLE_CLIENT_ID);
  authUrl.searchParams.append('redirect_uri', redirectUri);
  authUrl.searchParams.append('response_type', 'code');
  authUrl.searchParams.append('state', state);
  authUrl.searchParams.append('code_challenge', codeChallenge);
  authUrl.searchParams.append('code_challenge_method', 'S256');
  authUrl.searchParams.append('scope', 'https://www.googleapis.com/auth/spreadsheets https://www.googleapis.com/auth/drive.readonly');
  authUrl.searchParams.append('access_type', 'offline');
  authUrl.searchParams.append('prompt', 'consent');
  
  // Log authorization details (in development only)
  if (import.meta.env.DEV) {
    console.log('Google Auth URL:', authUrl.toString());
    console.log('Redirect URI:', redirectUri);
    console.log('Using client ID:', GOOGLE_CLIENT_ID);
  }
  
  // Redirect to authorization URL
  window.location.href = authUrl.toString();
};

// Exchange authorization code for tokens
export const exchangeCodeForToken = async (
  code: string,
  provider: string,
  codeVerifier: string,
  redirectUri: string
): Promise<boolean> => {
  try {
    console.log(`Exchanging code for ${provider} token...`);
    console.log(`Using redirect URI: ${redirectUri}`);
    
    // Instead of making the token exchange from the client,
    // we'll pass the authorization code to our backend and let it handle the exchange
    // This is more secure as it keeps client secrets on the server side
    
    const response = await fetch('/api/oauth/exchange', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        code,
        provider,
        codeVerifier,
        redirectUri
      })
    });
    
    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`Token exchange failed: ${response.status} ${errorText}`);
    }
    
    const result = await response.json();
    
    if (!result.success) {
      throw new Error(`Token exchange failed: ${result.message || 'Unknown error'}`);
    }
    
    console.log(`Successfully completed ${provider} authentication`);
    
    return true;
  } catch (error) {
    console.error('Token exchange error:', error);
    return false;
  }
};
